"""Filtro LLM: proveedores, errores y decisiones."""
import json

import httpx
import pandas as pd
import pytest

from conftest import make_cfg
from llm_filter import SYSTEM_PROMPT, LLMFilter, build_prompt, parse_json_response
from strategy import Signal


def signal(score=0.5):
    t = pd.Timestamp("2026-10-14 10:00", tz="UTC")
    return Signal(symbol="BTC/USDT:USDT", side="LONG", setup="AZUL", variant="tras_verde", timeframe="15m",
                  trend_timeframe="1h", candle_open_time=t, candle_close_time=t + pd.Timedelta(minutes=15),
                  entry_ref=60000, stop_loss=59000, atr=300, score=score, contexto=0.45, rechazo=0.55,
                  components={"fase": "BAJISTA", "vela": "martillo"},
                  rejection={"score": 0.55, "contexts_met": ["key_level"]},
                  reasons=["Flecha AZUL: Compra de menor riesgo (tras la verde)", "Mínimo más alto 60.000 (+1,2%)"])


def transport(handler):
    return httpx.MockTransport(handler)


@pytest.mark.asyncio
async def test_anthropic_request_and_go(tmp_path):
    seen = {}

    def handler(request: httpx.Request):
        seen["url"] = str(request.url)
        seen["headers"] = dict(request.headers)
        seen["body"] = json.loads(request.content)
        return httpx.Response(200, json={"content": [{"type": "text", "text": '{"decision":"GO","confidence":0.8,"reason":"estructura limpia"}'}]})

    cfg = make_cfg(tmp_path, llm_provider="anthropic", llm_model="claude-haiku-5-5", llm_api_key="sk-test")
    decision = await LLMFilter(cfg, transport=transport(handler)).evaluate(signal(), {"price": 60100})
    assert decision.allow and decision.decision == "GO" and decision.source == "llm"
    assert seen["url"] == "https://api.anthropic.com/v1/messages"
    assert seen["headers"]["x-api-key"] == "sk-test" and seen["headers"]["anthropic-version"] == "2023-06-01"
    assert seen["body"]["model"] == "claude-haiku-5-5" and "BTC/USDT:USDT" in seen["body"]["messages"][0]["content"]


@pytest.mark.asyncio
async def test_no_go_vetoes(tmp_path):
    handler = lambda r: httpx.Response(200, json={"choices": [{"message": {"content": '```json\n{"decision":"NO_GO","confidence":0.7,"reason":"SL lejos"}\n```'}}]})
    cfg = make_cfg(tmp_path, llm_provider="openrouter", llm_model="x", llm_api_key="k")
    decision = await LLMFilter(cfg, transport=transport(handler)).evaluate(signal(), {})
    assert not decision.allow and decision.decision == "NO_GO" and decision.reason == "SL lejos"


@pytest.mark.asyncio
@pytest.mark.parametrize("on_error,allowed", [("allow", True), ("block", False)])
async def test_errors_follow_llm_on_error(tmp_path, on_error, allowed):
    handler = lambda r: httpx.Response(500, text="caído")
    cfg = make_cfg(tmp_path, llm_provider="groq", llm_model="x", llm_api_key="k", llm_on_error=on_error)
    decision = await LLMFilter(cfg, transport=transport(handler)).evaluate(signal(), {})
    assert decision.allow is allowed and decision.source == "error"


@pytest.mark.asyncio
async def test_auto_approve_only_when_configured_and_disabled_skips_the_call(tmp_path):
    def handler(_):
        raise AssertionError("no debería llamar al modelo")
    cfg = make_cfg(tmp_path, llm_provider="anthropic", llm_model="m", llm_api_key="k", llm_auto_approve_score=0.6)
    assert (await LLMFilter(cfg, transport=transport(handler)).evaluate(signal(0.7), {})).source == "score_alto"
    assert (await LLMFilter(make_cfg(tmp_path), transport=transport(handler)).evaluate(signal(), {})).source == "desactivado"


@pytest.mark.asyncio
async def test_by_default_every_arrow_is_reviewed(tmp_path):
    calls = []

    def handler(request):
        calls.append(json.loads(request.content))
        return httpx.Response(200, json={"content": [{"type": "text", "text": '{"decision":"GO","confidence":0.6,"reason":"ok"}'}]})

    cfg = make_cfg(tmp_path, llm_provider="anthropic", llm_model="m", llm_api_key="k")   # LLM_AUTO_APPROVE_SCORE=1.0
    decision = await LLMFilter(cfg, transport=transport(handler)).evaluate(signal(0.95), {})
    assert decision.source == "llm" and len(calls) == 1


def test_prompt_speaks_her_language():
    candles = pd.DataFrame({"open": [1.0], "high": [1.1], "low": [0.9], "close": [1.05], "vol_ratio": [1.2],
                            "ema21": [1.0], "ema_fast": [0.98], "ema_mid": [0.95], "ema_slow": [0.9],
                            "bb_upper": [1.2], "bb_lower": [0.85]},
                           index=pd.date_range("2026-10-14", periods=1, freq="15min", tz="UTC"))
    text = build_prompt(signal(), {"price": 60100, "min_score": 0.4, "candles": candles,
                                   "htf": {"fase": "ALCISTA", "pila": "ALCISTA", "distancia_ema55_pct": 1.2,
                                           "posicion_bandas_pct": 60.0},
                                   "memoria": "Flecha AZUL_TRAS_VERDE: pocas muestras (3 de 20)"})
    assert "AZUL" in text and "tras la verde" in text and "Mínimo más alto" in text
    assert "Velas de 1 hora: fase ALCISTA" in text and "pocas muestras" in text
    assert "EMA21" in text and "Banda inferior" in text
    assert "ROJA" in SYSTEM_PROMPT and "AMARILLA" in SYSTEM_PROMPT and "VERDE" in SYSTEM_PROMPT


def test_parse_json_variants():
    assert parse_json_response('Respuesta: {"decision":"no go","confidence":"0.6","reason":"x"}')["decision"] == "NO_GO"
    with pytest.raises(ValueError):
        parse_json_response('{"decision":"QUIZÁS"}')
    with pytest.raises(ValueError):
        parse_json_response("sin json")
