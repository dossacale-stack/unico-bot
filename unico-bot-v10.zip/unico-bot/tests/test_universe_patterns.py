"""Universo de monedas y patrones WASHI."""
import sqlite3

import pandas as pd

import seed_patterns
import strategy
import universe
from conftest import random_walk

MARKETS = {mid: {"symbol": f"{mid[:-4]}/USDT:USDT", "linear": True, "swap": True, "active": True}
           for mid in ("AAAUSDT", "BBBUSDT", "CCCUSDT", "DDDUSDT", "1000PEPEUSDT", "XUSDC")}


def ticker(mid, last, prev24, prev1h, turnover=1e7):
    return {"symbol": mid, "lastPrice": str(last), "prevPrice24h": str(prev24), "price24hPcnt": str(last / prev24 - 1),
            "prevPrice1h": str(prev1h), "turnover24h": str(turnover), "fundingRate": "0.0001",
            "nextFundingTime": "1760000000000"}


def test_one_hour_change_uses_prev_price_1h_not_missing_field():
    raw = [ticker("AAAUSDT", 110, 100, 109.9), ticker("BBBUSDT", 101, 100, 95), ticker("CCCUSDT", 100, 100, 99),
           ticker("DDDUSDT", 90, 100, 89.9), ticker("1000PEPEUSDT", 2, 1, 1), ticker("XUSDC", 2, 1, 1)]
    rows = universe.parse_tickers(raw, MARKETS, ("1000", "100"))
    assert {r.market_id for r in rows} == {"AAAUSDT", "BBBUSDT", "CCCUSDT", "DDDUSDT"}
    top_1h = universe.select_top(rows, top_n_24h=0, top_n_1h=1)
    assert top_1h == ["BBB/USDT:USDT"]                 # +6,3% en la última hora
    top_24h = universe.select_top(rows, top_n_24h=1, top_n_1h=0)
    assert top_24h == ["AAA/USDT:USDT"]
    both = universe.select_top(rows, 2, 2)
    assert both[:2] == ["AAA/USDT:USDT", "BBB/USDT:USDT"] and len(both) == len(set(both))


def test_min_turnover_filter():
    raw = [ticker("AAAUSDT", 110, 100, 100, turnover=1000), ticker("BBBUSDT", 105, 100, 100)]
    rows = universe.parse_tickers(raw, MARKETS, ())
    assert universe.select_top(rows, 5, 0, min_turnover_24h=1e6) == ["BBB/USDT:USDT"]


def test_rank_from_closes_matches_live_rule():
    idx = pd.date_range("2026-01-01", periods=30, freq="h", tz="UTC")
    closes = pd.DataFrame({"A": [100.0] * 29 + [120.0], "B": [100.0] * 29 + [101.0], "C": [80.0] * 25 + [100.0] * 5}, index=idx)
    ranked = universe.rank_from_closes(closes, top_n_24h=1, top_n_1h=1)
    last = ranked[idx[-1]]
    assert last[0] == "C"          # +25% en 24 h
    assert "A" in last             # +20% en la última hora


def test_init_db_insert_and_summary(tmp_path, capsys):
    conn = sqlite3.connect(tmp_path / "p.db")
    seed_patterns.init_db(conn)
    assert seed_patterns.insert_patterns(conn, seed_patterns.PATTERNS) == 3
    assert seed_patterns.insert_patterns(conn, seed_patterns.PATTERNS) == 0      # no duplica
    seed_patterns.print_summary(conn)
    out = capsys.readouterr().out
    assert "WASHI_VERDE" in out and "WASHI_ROJA" in out and "WASHI_DORADA" in out


def test_extract_features_vocabulary_and_match():
    feat = strategy.build_features(random_walk(400, seed=11, drift=0.002))
    features = seed_patterns.extract_features(feat, -1)
    assert set(features) == set(seed_patterns.FEATURE_KEYS)
    assert features["trend"] in ("BULLISH", "BEARISH", "SIDEWAYS")
    assert features["bb_estado"] in ("SQUEEZE", "UPPER", "LOWER", "MID")
    templates = [dict(p, id=i + 1, name=seed_patterns.pattern_name(p)) for i, p in enumerate(seed_patterns.PATTERNS)]
    exact = {k: templates[0][k] for k in seed_patterns.FEATURE_KEYS}
    tpl, hits = seed_patterns.match_pattern(exact, "LONG", templates, 5)
    assert tpl["name"] == "WASHI_VERDE" and hits == 7
    tpl, _ = seed_patterns.match_pattern(exact, "SHORT", templates, 5)
    assert tpl is None or tpl["name"] == "WASHI_ROJA"


# ----------------------------------------------------------------------
# v9: memoria de la lista (la moneda sigue vigilada después de su subida)
# ----------------------------------------------------------------------
def test_watchlist_memory_keeps_recent_gainers_for_a_while():
    from datetime import datetime, timedelta, timezone
    from risk_manager import MemoryStore
    store = MemoryStore()
    memory = universe.WatchlistMemory(store, "DRY_RUN", memory_hours=96)
    t0 = datetime(2026, 10, 1, tzinfo=timezone.utc)
    assert memory.update(["LAB"], ["X1H"], now=t0) == ["LAB", "X1H"]
    later = memory.update(["SKY"], [], now=t0 + timedelta(hours=50))
    assert later == ["SKY", "LAB"]                       # LAB ya no sube, pero se sigue su ciclo
    gone = memory.update(["SKY"], [], now=t0 + timedelta(hours=97))
    assert gone == ["SKY"]                               # pasadas 96 h se olvida
    assert "X1H" not in memory.remembered()              # el top de 1 h no se recuerda


def test_membership_with_memory_matches_live_rule():
    idx = pd.date_range("2026-01-01", periods=200, freq="h", tz="UTC")
    pump = [100.0] * 40 + [150.0] * 160                  # A sube fuerte en la hora 40 y luego se queda quieta
    closes = pd.DataFrame({"A": pump, "B": [100.0 + 0.01 * i for i in range(200)],
                           "C": [100.0 + 0.02 * i for i in range(200)]}, index=idx)
    without = universe.membership_from_closes(closes, top_n_24h=1, top_n_1h=0, memory_hours=0)
    with_mem = universe.membership_from_closes(closes, top_n_24h=1, top_n_1h=0, memory_hours=96)
    t_after = idx[40 + 24 + 30]                          # 30 h después de salir del top de 24 h
    assert "A" not in without[t_after] and "A" in with_mem[t_after]
    assert "A" not in with_mem[idx[40 + 24 + 100]]       # pasadas 96 h ya no está


def test_liquidity_mask_excludes_illiquid_gainers():
    idx = pd.date_range("2026-01-01", periods=40, freq="h", tz="UTC")
    closes = pd.DataFrame({"A": [1.0] * 39 + [2.0], "B": [1.0] * 39 + [1.1]}, index=idx)
    volumes = pd.DataFrame({"A": [1.0] * 40, "B": [1e7] * 40}, index=idx)
    liquid = universe.turnover_24h_from_hourly(closes, volumes) >= 1e6
    members = universe.membership_from_closes(closes, 1, 0, 0, liquid)
    assert members[idx[-1]] == ["B"]
