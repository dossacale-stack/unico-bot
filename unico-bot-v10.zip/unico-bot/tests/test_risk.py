"""Tamaño de posición, costos, salidas y kill switch."""
from datetime import datetime, timedelta, timezone

import pytest

from risk_manager import (LONG, SHORT, EntryGuard, KillSwitch, MarketLimits, MemoryStore, PositionState,
                          RiskParams, close_at, funding_cost, plan_position, process_bar, replan_from_fill)

P = RiskParams()


def test_max_loss_is_40pct_of_15pct_margin_including_costs():
    plan, why = plan_position("X", LONG, 100.0, 98.0, 10_000.0, P, max_leverage=50)
    assert why == "OK"
    assert plan.margin_usd == pytest.approx(1_500.0)
    assert plan.max_loss_usd == pytest.approx(600.0)
    # Pérdida en el SL con comisiones y deslizamiento = exactamente el máximo permitido
    assert plan.risk_usd == pytest.approx(600.0, rel=1e-9)
    assert plan.leverage == 20
    assert plan.notional <= plan.margin_usd * plan.leverage + 1e-9


def test_tight_stop_is_capped_by_margin_and_leverage():
    plan, _ = plan_position("X", LONG, 100.0, 99.0, 10_000.0, P, max_leverage=50)
    assert plan.notional == pytest.approx(30_000.0)       # 1.500 de margen × 20x
    assert plan.risk_usd < 600.0


def test_rejects_stop_where_fees_eat_the_risk():
    plan, why = plan_position("X", LONG, 100.0, 99.6, 10_000.0, P)   # SL a 0,4%: comisiones = 27% del riesgo
    assert plan is None and "comisiones" in why


def test_rejects_wrong_side_stop():
    assert plan_position("X", LONG, 100.0, 101.0, 10_000.0, P)[0] is None
    assert plan_position("X", SHORT, 100.0, 99.0, 10_000.0, P)[0] is None


def test_leverage_respects_asset_maximum_and_st():
    plan, _ = plan_position("X", LONG, 100.0, 97.0, 10_000.0, P, max_leverage=8)
    assert plan.leverage == 8
    plan, _ = plan_position("X", LONG, 100.0, 97.0, 10_000.0, P, max_leverage=2)
    assert plan.leverage == 2
    plan, _ = plan_position("X", LONG, 100.0, 97.0, 10_000.0, P, max_leverage=50, is_st=True)
    assert plan.leverage == 5 and plan.margin_usd == pytest.approx(750.0)


def test_exchange_minimums():
    limits = MarketLimits(qty_step=1.0, min_qty=1.0, min_notional=5.0, tick_size=0.01)
    plan, why = plan_position("X", LONG, 50_000.0, 49_000.0, 100.0, P, limits=limits)
    assert plan is None and "mínimo" in why


def test_targets_are_2r_and_5r_and_break_even_at_3r():
    plan, _ = plan_position("X", SHORT, 100.0, 102.0, 10_000.0, P, max_leverage=50)
    assert plan.tp1_price == pytest.approx(96.0)
    assert plan.tp2_price == pytest.approx(90.0)
    assert plan.be_trigger == pytest.approx(94.0)
    assert plan.be_price == pytest.approx(100.0 * (1 - P.be_offset_pct))


def _state(side=LONG, entry=100.0, sl=98.0):
    plan, _ = plan_position("X", side, entry, sl, 10_000.0, P, max_leverage=50)
    return PositionState.from_plan(plan, entry_fee=entry * plan.contracts * P.taker_fee), plan


def test_full_winning_path_tp1_be_tp2_trailing():
    st, plan = _state()
    process_bar(st, open_=100, high=104.2, low=99.5, close=104, atr=1.0, p=P)       # TP1 (2R = 104)
    assert st.tp1_filled and st.contracts_open == pytest.approx(plan.contracts - plan.tp1_qty)
    process_bar(st, open_=104, high=106.5, low=103.5, close=106, atr=1.0, p=P)      # 3R → break-even
    assert st.be_set and st.sl >= 100.0
    process_bar(st, open_=106, high=110.5, low=105.5, close=110, atr=1.0, p=P)      # TP2 (5R = 110)
    assert st.tp2_filled
    assert st.trail_active and st.sl == pytest.approx(110.5 - 2.5)
    events = process_bar(st, open_=109, high=109.5, low=107.0, close=107.5, atr=1.0, p=P)
    assert st.closed and events[-1].kind == "TRAILING"
    expected = (plan.tp1_qty * 4 + plan.tp2_qty * 10 + (plan.contracts - plan.tp1_qty - plan.tp2_qty) * (108 * (1 - P.slippage_pct) - 100))
    assert st.realized_pnl == pytest.approx(expected, rel=1e-9)
    assert st.net_pnl == pytest.approx(st.realized_pnl - st.fees)


def test_stop_is_checked_before_targets_in_the_same_candle():
    st, plan = _state()
    events = process_bar(st, open_=100, high=105, low=97, close=101, atr=1.0, p=P)
    assert [e.kind for e in events] == ["SL"] and st.closed
    assert events[0].price == pytest.approx(98.0 * (1 - P.slippage_pct))


def test_gap_through_stop_fills_at_open():
    st, _ = _state()
    events = process_bar(st, open_=95, high=96, low=94, close=95.5, atr=1.0, p=P)
    assert events[0].price == pytest.approx(95 * (1 - P.slippage_pct))


def test_loss_at_stop_is_about_one_r_with_costs():
    st, plan = _state()
    process_bar(st, open_=100, high=100.5, low=97.9, close=98, atr=1.0, p=P)
    assert st.net_pnl == pytest.approx(-plan.risk_usd, rel=0.03)
    assert st.net_pnl / st.r_value == pytest.approx(-1.06, abs=0.03)


def test_partial_accounting_uses_original_contracts():
    """La v7.3 contaba el TP2 sobre el margen ya reducido (281 en vez de 375)."""
    st, plan = _state()
    process_bar(st, open_=100, high=104.1, low=99.9, close=104, atr=0.0, p=P)
    process_bar(st, open_=104, high=110.1, low=103.9, close=110, atr=0.0, p=P)
    assert plan.tp1_qty == pytest.approx(plan.tp2_qty)
    assert st.contracts_open == pytest.approx(plan.contracts - 2 * plan.tp1_qty)


def test_replan_keeps_structural_stop_and_rejects_fill_past_stop():
    plan, _ = plan_position("X", LONG, 100.0, 98.0, 10_000.0, P, max_leverage=50)
    moved = replan_from_fill(plan, 100.5, plan.contracts, P)
    assert moved.stop_loss == 98.0 and moved.tp1_price == pytest.approx(100.5 + 2 * 2.5)
    assert replan_from_fill(plan, 97.5, plan.contracts, P) is None


def test_funding_sign():
    assert funding_cost(LONG, 1.0, 100.0, 0.0001) == pytest.approx(0.01)
    assert funding_cost(SHORT, 1.0, 100.0, 0.0001) == pytest.approx(-0.01)


def test_close_at_applies_taker_and_slippage():
    st, plan = _state()
    ev = close_at(st, 101.0, P)
    assert ev.price == pytest.approx(101 * (1 - P.slippage_pct))
    assert st.closed


def test_kill_switch_uses_real_equity_and_resets_each_day():
    store = MemoryStore()
    ks = KillSwitch(store, "LIVE", 15.0, 25.0)
    day1 = datetime(2026, 10, 14, 10, tzinfo=timezone.utc)   # miércoles
    assert ks.evaluate(500.0, day1) == (False, "")             # la referencia es el capital real, no 10.000
    blocked, reason = ks.evaluate(420.0, day1 + timedelta(hours=1))
    assert blocked and "diaria" in reason
    assert ks.evaluate(430.0, day1 + timedelta(hours=5))[0]     # sigue bloqueado ese día
    assert ks.evaluate(430.0, day1 + timedelta(days=1, hours=1)) == (False, "")   # nuevo día, nueva referencia
    assert store.get_state("LIVE:kill_switch")["day_start"] == 430.0


def test_kill_switch_weekly_limit_blocks_until_monday():
    store = MemoryStore()
    ks = KillSwitch(store, "LIVE", 15.0, 25.0)
    monday = datetime(2026, 10, 12, 1, tzinfo=timezone.utc)
    ks.evaluate(1000.0, monday)
    for d, eq in ((1, 900.0), (2, 800.0), (3, 740.0)):
        blocked, reason = ks.evaluate(eq, monday + timedelta(days=d))
    assert blocked and "semanal" in reason
    assert ks.evaluate(745.0, monday + timedelta(days=5))[0]
    assert not ks.evaluate(745.0, monday + timedelta(days=7, hours=1))[0]


def test_entry_guard_cooldown_and_daily_limit():
    store = MemoryStore()
    guard = EntryGuard(store, "DRY_RUN", cooldown_minutes=60, max_entries_daily=2)
    now = datetime(2026, 10, 14, 12, tzinfo=timezone.utc)
    guard.register_entry("X", now)
    guard.register_close("X", now)
    assert not guard.check("X", now + timedelta(minutes=30))[0]
    assert guard.check("X", now + timedelta(minutes=61))[0]
    guard.register_entry("X", now)
    assert not guard.check("X", now + timedelta(hours=3))[0]
    assert guard.check("X", now + timedelta(days=1))[0]
