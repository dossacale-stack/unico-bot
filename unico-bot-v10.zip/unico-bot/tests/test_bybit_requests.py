"""
Peticiones reales que ccxt construye para Bybit v5 (se intercepta la capa HTTP, sin red).
Comprueba formatos de símbolo, SL adjunto, trading-stop, posiciones y velas cerradas.
"""
import json
import time
from urllib.parse import parse_qs, urlparse

import ccxt
import pytest

from bybit_api_manager import BybitAPIManager
from conftest import make_cfg

NOW = int(time.time() * 1000)


def instrument(symbol, base, max_lev="100.00", qty_step="0.001", min_qty="0.001", tick="0.10", notional="5"):
    return {"symbol": symbol, "contractType": "LinearPerpetual", "status": "Trading", "baseCoin": base,
            "quoteCoin": "USDT", "launchTime": "1585526400000", "deliveryTime": "0", "deliveryFeeRate": "",
            "priceScale": "2", "leverageFilter": {"minLeverage": "1", "maxLeverage": max_lev, "leverageStep": "0.01"},
            "priceFilter": {"minPrice": "0.10", "maxPrice": "1999999.80", "tickSize": tick},
            "lotSizeFilter": {"maxOrderQty": "1190.000", "minOrderQty": min_qty, "qtyStep": qty_step,
                              "postOnlyMaxOrderQty": "1190.000", "maxMktOrderQty": "500.000",
                              "minNotionalValue": notional},
            "unifiedMarginTrade": True, "fundingInterval": 480, "settleCoin": "USDT", "copyTrading": "both",
            "upperFundingRate": "0.00375", "lowerFundingRate": "-0.00375", "isPreListing": False,
            "preListingInfo": None, "displayName": ""}


def ok(result):
    return {"retCode": 0, "retMsg": "OK", "result": result, "retExtInfo": {}, "time": NOW}


class Router:
    def __init__(self):
        self.requests = []
        self.fail = None
        self.positions = [{
            "positionIdx": 0, "riskId": 1, "symbol": "BTCUSDT", "side": "Buy", "size": "0.05", "avgPrice": "60000",
            "positionValue": "3000", "tradeMode": 0, "positionStatus": "Normal", "leverage": "20", "markPrice": "60100",
            "liqPrice": "", "bustPrice": "", "positionIM": "150", "positionMM": "15", "tpslMode": "Full",
            "takeProfit": "", "stopLoss": "59000", "trailingStop": "0", "unrealisedPnl": "5", "curRealisedPnl": "-1.65",
            "cumRealisedPnl": "-1.65", "createdTime": str(NOW - 60_000), "updatedTime": str(NOW), "seq": 1,
        }]

    def __call__(self, url, method="GET", headers=None, body=None):
        parsed = urlparse(url)
        query = {k: v[0] for k, v in parse_qs(parsed.query).items()}
        payload = json.loads(body) if body else {}
        self.requests.append((method, parsed.path, query, payload))
        if self.fail:
            raise self.fail
        path = parsed.path
        if path == "/v5/market/instruments-info":
            return ok({"category": "linear", "nextPageCursor": "", "list": [
                instrument("BTCUSDT", "BTC"), instrument("STXUSDT", "STX", max_lev="50.00", qty_step="0.1", min_qty="0.1", tick="0.0001")]})
        if path == "/v5/market/time":
            return ok({"timeSecond": str(NOW // 1000), "timeNano": str(NOW * 10**6)})
        if path == "/v5/market/kline":
            step = 3_600_000
            last_open = (NOW // step) * step                     # vela en formación
            rows = [[str(last_open - i * step), "100", "101", "99", "100.5", "10", "1000"] for i in range(0, 300)]
            return ok({"category": "linear", "symbol": query.get("symbol"), "list": rows})
        if path == "/v5/market/tickers":
            return ok({"category": "linear", "list": [{"symbol": "BTCUSDT", "lastPrice": "60100", "markPrice": "60090",
                                                       "fundingRate": "0.0001", "nextFundingTime": str(NOW + 3_600_000),
                                                       "prevPrice1h": "59900", "prevPrice24h": "58000",
                                                       "price24hPcnt": "0.0362", "turnover24h": "1000000000"}]})
        if path == "/v5/order/create":
            return ok({"orderId": "abc123", "orderLinkId": payload.get("orderLinkId", "")})
        if path == "/v5/position/list":
            return ok({"category": "linear", "nextPageCursor": "", "list": self.positions})
        if path in ("/v5/position/trading-stop", "/v5/position/set-leverage", "/v5/position/switch-mode"):
            return ok({})
        if path == "/v5/account/wallet-balance":
            return ok({"list": [{"accountType": "UNIFIED", "totalEquity": "10234.5", "totalWalletBalance": "10200",
                                 "totalAvailableBalance": "8000", "totalPerpUPL": "34.5", "coin": []}]})
        if path == "/v5/position/closed-pnl":
            return ok({"category": "linear", "nextPageCursor": "", "list": [
                {"symbol": "BTCUSDT", "closedPnl": "-61.2", "closedSize": "0.05", "avgExitPrice": "58790",
                 "openFee": "1.65", "closeFee": "1.61", "updatedTime": str(NOW)}]})
        if path in ("/v5/user/query-api",):
            return ok({"unified": 1, "uta": 1})
        if path == "/v5/account/info":
            return ok({"unifiedMarginStatus": 5})
        raise AssertionError(f"Endpoint no simulado: {method} {path}")


@pytest.fixture
def api(tmp_path):
    cfg = make_cfg(tmp_path, mode="LIVE", api_key="key", api_secret="secret", confirm_live=True)
    manager = BybitAPIManager(cfg)
    router = Router()
    manager.data_ex.fetch = router
    manager.trade_ex.fetch = router
    manager.router = router
    return manager


def last_request(router, path):
    return [r for r in router.requests if r[1] == path][-1]


async def test_markets_limits_leverage_and_st(api):
    await api.load_markets()
    assert set(api.markets_by_id) == {"BTCUSDT", "STXUSDT"}
    limits = api.limits("BTC/USDT:USDT")
    assert (limits.qty_step, limits.min_qty, limits.min_notional, limits.tick_size) == (0.001, 0.001, 5.0, 0.1)
    assert api.max_leverage("STX/USDT:USDT") == 50
    assert api.is_st("STX/USDT:USDT") is False          # la v7.3 la marcaba como ST por contener "ST"
    assert api.listing_time_ms("BTC/USDT:USDT") == 1585526400000


async def test_entry_order_carries_stop_loss_with_native_symbol(api):
    await api.load_markets()
    await api.create_entry_order("BTC/USDT:USDT", "LONG", 0.05, 58800.0, "unico-test1")
    _m, _p, _q, body = last_request(api.router, "/v5/order/create")
    assert body["symbol"] == "BTCUSDT" and body["side"] == "Buy" and body["orderType"] == "Market"
    assert body["qty"] == "0.05" and body["stopLoss"] == "58800" and body["tpslMode"] == "Full"
    assert body["slTriggerBy"] == "LastPrice" and body["orderLinkId"] == "unico-test1"
    assert body.get("reduceOnly") in (None, False)


async def test_take_profit_orders_are_reduce_only_limits(api):
    await api.load_markets()
    await api.create_reduce_only_limit("BTC/USDT:USDT", "LONG", 0.012, 62412.37, "unico-test1-tp1")
    body = last_request(api.router, "/v5/order/create")[3]
    assert body["side"] == "Sell" and body["orderType"] == "Limit" and body["reduceOnly"] is True
    assert body["timeInForce"] == "GTC" and body["price"] == "62412.4" and body["qty"] == "0.012"


async def test_trading_stop_uses_native_symbol(api):
    await api.load_markets()
    await api.set_trading_stop("BTC/USDT:USDT", stop_loss=60090.04)
    body = last_request(api.router, "/v5/position/trading-stop")[3]
    assert body == {"category": "linear", "symbol": "BTCUSDT", "tpslMode": "Full", "positionIdx": 0,
                    "stopLoss": "60090", "slTriggerBy": "LastPrice"}


async def test_positions_are_mapped_and_requested_correctly(api):
    await api.load_markets()
    positions = await api.fetch_open_positions()
    _m, _p, query, _b = last_request(api.router, "/v5/position/list")
    assert query["category"] == "linear" and query["settleCoin"] == "USDT"
    assert positions == [{**positions[0], "symbol": "BTC/USDT:USDT", "side": "LONG", "contracts": 0.05,
                          "entry_price": 60000.0, "stop_loss": 59000.0}]


async def test_only_closed_candles_and_cache(api):
    await api.load_markets()
    df = await api.fetch_ohlcv("BTC/USDT:USDT", "1h", limit=250)
    forming = (NOW // 3_600_000) * 3_600_000
    assert int(df.index[-1].value // 10**6) == forming - 3_600_000
    calls = len([r for r in api.router.requests if r[1] == "/v5/market/kline"])
    await api.fetch_ohlcv("BTC/USDT:USDT", "1h", limit=250)
    assert len([r for r in api.router.requests if r[1] == "/v5/market/kline"]) == calls   # caché


async def test_network_error_raises_instead_of_inventing_prices(api):
    await api.load_markets()
    api.router.fail = ccxt.NetworkError("timeout")
    with pytest.raises(ccxt.NetworkError):
        await api.fetch_ohlcv("BTC/USDT:USDT", "15m")
    assert api.consecutive_failures == 1


async def test_equity_from_unified_account(api):
    eq = await api.get_equity()
    assert eq == {"equity": 10234.5, "available": 8000.0, "wallet": 10200.0, "upnl": 34.5}


async def test_closed_pnl_windows_are_at_most_seven_days(api):
    await api.load_markets()
    await api.fetch_closed_pnl("BTC/USDT:USDT", NOW - 20 * 86_400_000, NOW)
    windows = [r[2] for r in api.router.requests if r[1] == "/v5/position/closed-pnl"]
    assert len(windows) == 3
    for q in windows:
        assert q["symbol"] == "BTCUSDT" and int(q["endTime"]) - int(q["startTime"]) <= 7 * 86_400_000


async def test_dry_run_has_no_trading_account(tmp_path):
    manager = BybitAPIManager(make_cfg(tmp_path))
    assert manager.trade_ex is None
    with pytest.raises(RuntimeError):
        await manager.fetch_open_positions()


def test_demo_and_testnet_endpoints(tmp_path):
    demo = BybitAPIManager(make_cfg(tmp_path, mode="DEMO", api_key="k", api_secret="s"))
    assert "api-demo" in json.dumps(demo.trade_ex.urls["api"]) and "api-demo" not in json.dumps(demo.data_ex.urls["api"])
    testnet = BybitAPIManager(make_cfg(tmp_path, mode="TESTNET", api_key="k", api_secret="s"))
    assert "testnet" in json.dumps(testnet.trade_ex.urls["api"]) and "testnet" in json.dumps(testnet.data_ex.urls["api"])
