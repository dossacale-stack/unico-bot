"""El backtest simula una sola cartera con costos y la misma lógica que el bot."""
import pandas as pd
import pytest

import backtest
from conftest import make_cfg
from fake_market import FakeData


@pytest.fixture(scope="module")
def result(tmp_path_factory):
    tmp = tmp_path_factory.mktemp("bt")
    cfg = make_cfg(tmp, max_positions=3)
    summary = backtest.run_backtest(cfg, days=45, out_dir=str(tmp / "out"), data=FakeData(30))
    trades = pd.read_csv(tmp / "out" / "trades.csv", parse_dates=["entrada", "salida"])
    equity = pd.read_csv(tmp / "out" / "equity.csv", index_col=0, parse_dates=True)
    return cfg, summary, trades, equity, tmp


def test_report_files_and_keys(result):
    _cfg, summary, trades, equity, tmp = result
    for name in ("summary.json", "trades.csv", "equity.csv", "report.md", "status.json"):
        assert (tmp / "out" / name).exists()
    for key in ("rentabilidad_pct", "caida_maxima_pct", "factor_beneficio", "r_medio", "mitades", "limitaciones"):
        assert key in summary
    assert summary["operaciones"] == len(trades) > 0


def test_single_portfolio_respects_max_positions(result):
    cfg, _summary, _trades, equity, _ = result
    assert equity["open_positions"].max() <= cfg.max_positions


def test_costs_are_charged(result):
    _cfg, summary, trades, _equity, _ = result
    assert summary["comisiones_total"] > 0
    assert (trades["comisiones"] > 0).all()
    assert trades["funding"].abs().sum() > 0


def test_trades_last_their_real_duration_and_no_200_candle_skip(result):
    _cfg, _summary, trades, _equity, _ = result
    assert trades["duracion_h"].nunique() > 3
    assert (trades["duracion_h"] < 200).any()
    gaps = []
    for _, g in trades.sort_values("entrada").groupby("simbolo"):
        gaps += list((g["entrada"].diff().dropna().dt.total_seconds() / 3600))
    assert not gaps or min(gaps) < 200


def test_capital_equals_initial_plus_net_results(result):
    cfg, summary, trades, equity, _ = result
    assert summary["capital_final"] == pytest.approx(cfg.paper_balance + trades["pnl_neto"].sum(), rel=1e-6, abs=0.05)
    assert float(equity["equity"].iloc[-1]) == pytest.approx(summary["capital_final"], abs=0.05)


def test_entries_happen_after_the_signal_candle(result):
    _cfg, _summary, trades, _equity, _ = result
    assert (trades["entrada"] >= trades["senal"]).all()
    assert (trades["salida"] > trades["entrada"]).all()


def test_report_by_arrow_and_counters(result):
    import strategy
    _cfg, summary, trades, _equity, tmp = result
    assert summary["por_flecha"] and {r["flecha"] for r in summary["por_flecha"]} <= set(strategy.SETUP_CODES)
    assert set(trades["flecha"]) <= set(strategy.SETUP_CODES)
    assert summary["contadores"]["flechas_detectadas"] > 0 and summary["contadores"]["abiertas"] == len(trades)
    assert "Por flecha" in (tmp / "out" / "report.md").read_text(encoding="utf-8")


def test_opposite_warning_closes_the_right_side_and_only_in_profit(result):
    _cfg, _summary, trades, _equity, _ = result
    verde = trades[trades["motivo_salida"] == "SALIDA_VERDE"]
    tope = trades[trades["motivo_salida"] == "SALIDA_TOPE"]
    assert (verde["lado"] == "SHORT").all() and (tope["lado"] == "LONG").all()
    assert len(verde) + len(tope) > 0
    assert (pd.concat([verde, tope])["pnl_bruto"] > 0).all()


def test_opposite_warning_exit_can_be_disabled(tmp_path):
    cfg = make_cfg(tmp_path, max_positions=3, exit_on_opposite=False)
    backtest.run_backtest(cfg, days=20, out_dir=str(tmp_path / "out"), data=FakeData(10))
    trades = pd.read_csv(tmp_path / "out" / "trades.csv")
    assert not trades["motivo_salida"].isin(["SALIDA_VERDE", "SALIDA_TOPE"]).any()


def test_days_are_capped_for_railway_memory(tmp_path):
    cfg = make_cfg(tmp_path)
    summary = backtest.run_backtest(cfg, days=900, out_dir=None, data=FakeData(3))
    assert summary["parametros"]["dias"] == backtest.MAX_DAYS
