"""Ejecución: simulación (DRY_RUN) y exchange (DEMO/TESTNET/LIVE) con un Bybit simulado."""
import ccxt
import pandas as pd
import pytest

from conftest import bars, make_cfg
from database import Database
from order_executor import ExchangeBroker, PaperBroker, now_ms
from risk_manager import LONG, SHORT, RiskParams, plan_position
from strategy import Signal

SYM = "BTC/USDT:USDT"


def make_signal(side=LONG, entry=60000.0, sl=58800.0):
    t = pd.Timestamp("2026-10-14 10:00", tz="UTC")
    setup, variant = ("AZUL", "retroceso") if side == LONG else ("ROJA", "tras_techo")
    return Signal(symbol=SYM, side=side, setup=setup, variant=variant, timeframe="15m", trend_timeframe="1h",
                  candle_open_time=t, candle_close_time=t + pd.Timedelta(minutes=15), entry_ref=entry, stop_loss=sl,
                  atr=300.0, score=0.5, signal_id=None)


def setup(tmp_path, fake_api, mode, closed=None):
    cfg = make_cfg(tmp_path, mode=mode, api_key="k", api_secret="s")
    db = Database(cfg.db_path)
    rp = RiskParams.from_config(cfg)
    closed = closed if closed is not None else []
    cls = PaperBroker if mode == "DRY_RUN" else ExchangeBroker
    broker = cls(fake_api, db, cfg, rp, on_close=closed.append)
    return broker, db, rp, closed


def plan_for(fake_api, rp, side=LONG, sl=58800.0, balance=10_000.0):
    plan, why = plan_position(SYM, side, fake_api.prices[SYM], sl, balance, rp, max_leverage=100,
                              limits=fake_api.limits(SYM))
    assert plan is not None, why
    return plan


# ======================================================================
# Exchange
# ======================================================================
async def test_entry_is_sent_with_stop_loss_and_tps_are_reduce_only(tmp_path, fake_api):
    broker, db, rp, _ = setup(tmp_path, fake_api, "LIVE")
    pid = await broker.open_position(plan_for(fake_api, rp), make_signal())
    assert pid is not None
    entry_call = next(c for c in fake_api.calls if c[0] == "create_entry_order")
    assert entry_call[4] == 58800.0                                   # SL adjunto en la misma orden
    tp_calls = [c for c in fake_api.calls if c[0] == "create_reduce_only_limit"]
    assert len(tp_calls) == 2 and {round(c[4]) for c in tp_calls} == {62400, 66000}
    row = db.get_position(pid)
    assert row["status"] == "OPEN" and row["entry_price"] == 60000.0 and row["fees_paid"] > 0


async def test_rejected_entry_never_opens_without_stop(tmp_path, fake_api):
    fake_api.reject_entry = ccxt.InvalidOrder("SL inválido")
    broker, db, rp, _ = setup(tmp_path, fake_api, "LIVE")
    assert await broker.open_position(plan_for(fake_api, rp), make_signal()) is None
    assert not fake_api.positions
    assert not any(c[0] == "create_entry_order" and c[4] is None for c in fake_api.calls)
    assert db.query("SELECT status FROM positions")[0]["status"] == "CANCELLED"


async def test_missing_stop_is_restored(tmp_path, fake_api):
    fake_api.drop_sl_on_entry = True
    broker, db, rp, _ = setup(tmp_path, fake_api, "LIVE")
    await broker.open_position(plan_for(fake_api, rp), make_signal())
    assert fake_api.positions[SYM]["stop_loss"] == 58800.0
    assert ("set_trading_stop", SYM, 58800.0) in fake_api.calls


async def test_position_is_never_dropped_when_bybit_does_not_answer(tmp_path, fake_api):
    broker, db, rp, closed = setup(tmp_path, fake_api, "LIVE")
    pid = await broker.open_position(plan_for(fake_api, rp), make_signal())
    fake_api.fail_positions = True
    await broker.manage()
    assert db.get_position(pid)["status"] == "OPEN" and not closed


async def test_tp_fills_break_even_trailing_and_close_are_recorded(tmp_path, fake_api):
    broker, db, rp, closed = setup(tmp_path, fake_api, "LIVE")
    pid = await broker.open_position(plan_for(fake_api, rp), make_signal())
    row = db.get_position(pid)
    start = pd.Timestamp(row["last_check_ms"], unit="ms", tz="UTC")

    fake_api.move(SYM, 62500.0)                           # TP1 (62.400) ejecutado por "Bybit"
    fake_api.minute_bars[SYM] = bars([(62000, 62500, 61900, 62450)], start=start)
    await broker.manage()
    row = db.get_position(pid)
    assert row["tp1_filled"] == 1 and row["contracts_open"] < row["contracts_initial"]
    assert row["trail_active"] == 1                         # trailing tras TP1
    sl_after_tp1 = row["sl_current"]
    assert fake_api.positions[SYM]["stop_loss"] == pytest.approx(sl_after_tp1, abs=0.1)

    fake_api.move(SYM, 63700.0)                           # 3R = 63.600 → break-even
    fake_api.minute_bars[SYM] = bars([(62450, 62600, 62400, 62550), (62550, 63700, 62500, 63650)], start=start)
    await broker.manage()
    row = db.get_position(pid)
    assert row["be_set"] == 1 and row["sl_current"] >= 60000.0
    assert fake_api.positions[SYM]["stop_loss"] >= 60000.0

    fake_api.move(SYM, fake_api.positions[SYM]["stop_loss"] - 1)   # Bybit ejecuta el SL
    await broker.manage()
    row = db.get_position(pid)
    assert row["status"] == "CLOSED" and row["exit_reason"] in ("TRAILING", "BREAK_EVEN")
    assert row["exchange_pnl"] is not None and row["net_pnl"] == pytest.approx(row["exchange_pnl"])
    assert closed and closed[0]["id"] == pid
    assert not fake_api.orders                              # el TP2 sobrante quedó cancelado


async def test_stop_loss_hit_on_exchange_is_recorded_as_loss(tmp_path, fake_api):
    broker, db, rp, closed = setup(tmp_path, fake_api, "LIVE")
    pid = await broker.open_position(plan_for(fake_api, rp), make_signal())
    fake_api.move(SYM, 58700.0)
    await broker.manage()
    row = db.get_position(pid)
    assert row["status"] == "CLOSED" and row["exit_reason"] == "SL" and row["net_pnl"] < 0
    assert row["r_multiple"] == pytest.approx(-1.0, abs=0.1)


async def test_external_position_is_shown_but_not_touched(tmp_path, fake_api):
    broker, db, rp, _ = setup(tmp_path, fake_api, "LIVE")
    fake_api.positions["BTC/USDT:USDT"] = {"side": SHORT, "contracts": 0.5, "entry_price": 61000.0, "stop_loss": None}
    await broker.manage()
    rows = db.open_positions("LIVE")
    assert len(rows) == 1 and rows[0]["origin"] == "EXTERNAL"
    assert not any(c[0] in ("set_trading_stop", "close_market") for c in fake_api.calls)
    events = db.recent_events("LIVE")
    assert any("NO TIENE STOP-LOSS" in e["message"] for e in events)


async def test_pending_entry_is_confirmed_on_next_cycle(tmp_path, fake_api, monkeypatch):
    broker, db, rp, _ = setup(tmp_path, fake_api, "LIVE")

    async def slow_wait(*a, **k):
        return None
    monkeypatch.setattr(broker, "_wait_position", slow_wait)
    pid = await broker.open_position(plan_for(fake_api, rp), make_signal())
    assert pid is None
    row = db.query("SELECT * FROM positions")[0]
    assert row["status"] == "PENDING"
    await broker.manage()
    row = db.get_position(row["id"])
    assert row["status"] == "OPEN" and row["tp1_price"] > row["entry_price"]


async def test_startup_reconciliation_after_restart(tmp_path, fake_api):
    broker, db, rp, _ = setup(tmp_path, fake_api, "LIVE")
    pid = await broker.open_position(plan_for(fake_api, rp), make_signal())
    # "Reinicio": nueva instancia con la misma base de datos
    broker2, _, _, _ = setup(tmp_path, fake_api, "LIVE")
    await broker2.startup()
    assert [r["id"] for r in db.open_positions("LIVE")] == [pid]


# ======================================================================
# Simulación (DRY_RUN)
# ======================================================================
async def test_paper_entry_costs_and_cash(tmp_path, fake_api):
    broker, db, rp, _ = setup(tmp_path, fake_api, "DRY_RUN")
    pid = await broker.open_position(plan_for(fake_api, rp), make_signal())
    row = db.get_position(pid)
    assert row["entry_price"] == pytest.approx(60000 * (1 + rp.slippage_pct))
    assert broker.balance() == pytest.approx(10_000 - row["fees_paid"])


async def test_paper_detects_wick_on_one_minute_candles(tmp_path, fake_api):
    broker, db, rp, closed = setup(tmp_path, fake_api, "DRY_RUN")
    pid = await broker.open_position(plan_for(fake_api, rp), make_signal())
    past = (now_ms() // 60_000 - 5) * 60_000          # vela de 1 minuto ya cerrada
    db.update_position(pid, last_check_ms=past)
    row = db.get_position(pid)
    start = pd.Timestamp(past, unit="ms", tz="UTC")
    sl = row["sl_current"]
    fake_api.minute_bars[SYM] = bars([(60000, 60100, sl - 50, 59900)], start=start)   # mecha que toca el SL
    fake_api.prices[SYM] = 59950.0
    await broker.manage()
    row = db.get_position(pid)
    assert row["status"] == "CLOSED" and row["exit_reason"] == "SL"
    fills = db.fills_for(pid)
    cash_expected = 10_000 + sum(f["pnl"] - f["fee"] for f in fills)
    assert broker.balance() == pytest.approx(cash_expected)
    assert row["net_pnl"] == pytest.approx(cash_expected - 10_000)


async def test_paper_charges_funding(tmp_path, fake_api):
    broker, db, rp, _ = setup(tmp_path, fake_api, "DRY_RUN")
    fake_api.next_funding_ms = now_ms() - 1000
    pid = await broker.open_position(plan_for(fake_api, rp), make_signal(), meta={"next_funding_ms": fake_api.next_funding_ms})
    fake_api.next_funding_ms = now_ms() + 8 * 3_600_000
    await broker.manage()
    row = db.get_position(pid)
    assert row["funding_paid"] > 0                                       # LONG con tasa positiva paga
    assert any(f["kind"] == "FUNDING" for f in db.fills_for(pid))


async def test_price_beyond_new_stop_closes_at_market(tmp_path, fake_api):
    broker, db, rp, closed = setup(tmp_path, fake_api, "LIVE")
    pid = await broker.open_position(plan_for(fake_api, rp), make_signal())
    fake_api.positions[SYM]["stop_loss"] = None            # Bybit perdió el SL…
    fake_api.prices[SYM] = 58000.0                        # …y el precio ya está por debajo del SL
    await broker.manage()
    assert any(c[0] == "close_market" for c in fake_api.calls)
    await broker.manage()                                  # siguiente ciclo: se registra el cierre
    row = db.get_position(pid)
    assert row["status"] == "CLOSED" and row["exit_reason"] == "SL"


async def test_client_order_ids_fit_bybit_limit(tmp_path, fake_api):
    broker, db, rp, _ = setup(tmp_path, fake_api, "LIVE")
    pid = await broker.open_position(plan_for(fake_api, rp), make_signal())
    row = db.get_position(pid)
    assert len(row["client_order_id"]) <= 36 and len(row["client_order_id"] + "-tp1") <= 36


# ======================================================================
# v9: flecha guardada y cierre por aviso contrario
# ======================================================================
async def test_position_stores_its_arrow(tmp_path, fake_api):
    broker, db, rp, _ = setup(tmp_path, fake_api, "LIVE")
    pid = await broker.open_position(plan_for(fake_api, rp), make_signal())
    row = db.get_position(pid)
    assert row["setup"] == "AZUL" and row["variant"] == "retroceso"


async def test_exchange_close_now_on_opposite_warning(tmp_path, fake_api):
    broker, db, rp, closed = setup(tmp_path, fake_api, "LIVE")
    pid = await broker.open_position(plan_for(fake_api, rp), make_signal())
    fake_api.prices[SYM] = 61000.0                         # va ganando (todavía sin TP1)
    assert await broker.close_now(db.get_position(pid), "SALIDA_TOPE", note="Aviso TOPE")
    assert any(c[0] == "close_market" for c in fake_api.calls)
    await broker.manage()                                  # Bybit confirma el cierre
    row = db.get_position(pid)
    assert row["status"] == "CLOSED" and row["exit_reason"] == "SALIDA_TOPE" and row["net_pnl"] > 0
    assert closed and not fake_api.orders                  # los TP sobrantes quedaron cancelados


async def test_exchange_close_now_when_bybit_already_closed_it(tmp_path, fake_api):
    broker, db, rp, closed = setup(tmp_path, fake_api, "LIVE")
    pid = await broker.open_position(plan_for(fake_api, rp), make_signal())
    fake_api.move(SYM, 58700.0)                           # el SL ya saltó en Bybit
    assert not await broker.close_now(db.get_position(pid), "SALIDA_TOPE")
    row = db.get_position(pid)
    assert row["status"] == "CLOSED" and row["exit_reason"] == "SL"
    assert not any(c[0] == "close_market" for c in fake_api.calls)


async def test_paper_close_now_records_exit_and_cash(tmp_path, fake_api):
    broker, db, rp, closed = setup(tmp_path, fake_api, "DRY_RUN")
    pid = await broker.open_position(plan_for(fake_api, rp, side=SHORT, sl=61200.0), make_signal(SHORT, sl=61200.0))
    fake_api.prices[SYM] = 59000.0                         # el corto va ganando y aparece la VERDE
    assert await broker.close_now(db.get_position(pid), "SALIDA_VERDE")
    row = db.get_position(pid)
    assert row["status"] == "CLOSED" and row["exit_reason"] == "SALIDA_VERDE" and row["net_pnl"] > 0
    fills = db.fills_for(pid)
    assert any(f["kind"] == "SALIDA_VERDE" for f in fills)
    assert broker.balance() == pytest.approx(10_000 + sum(f["pnl"] - f["fee"] for f in fills))
    assert closed and closed[0]["id"] == pid
