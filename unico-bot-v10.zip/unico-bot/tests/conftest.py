"""Utilidades comunes de las pruebas (sin red, sin claves reales)."""
from __future__ import annotations

import os
import sys
import time
from dataclasses import replace
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

for var in ("BOT_MODE", "CONFIRM_LIVE", "BYBIT_API_KEY", "BYBIT_API_SECRET", "ANTHROPIC_API_KEY",
            "OPENROUTER_API_KEY", "GROQ_API_KEY", "LLM_PROVIDER", "DASHBOARD_PASSWORD", "DB_PATH", "DATA_DIR",
            "MAX_POSITIONS", "MIN_SCORE", "POSITION_PCT", "SL_PCT", "LEVERAGE", "TP_MULTIPLE"):
    os.environ.pop(var, None)

from config import Config  # noqa: E402
from risk_manager import LONG, MarketLimits  # noqa: E402


def make_cfg(tmp_path, **overrides) -> Config:
    base = Config(db_path=str(tmp_path / "test.db"), data_dir=str(tmp_path / "data"))
    return replace(base, **overrides)


def random_walk(n: int = 400, seed: int = 0, drift: float = 0.0, vol: float = 0.01, start: str = "2025-01-01",
                freq: str = "h", price: float = 100.0) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    rets = rng.normal(drift, vol, n)
    close = price * np.exp(np.cumsum(rets))
    open_ = np.concatenate([[close[0]], close[:-1]])
    spread = np.abs(rng.normal(0, vol, n)) * close
    high = np.maximum(open_, close) + spread * rng.random(n)
    low = np.minimum(open_, close) - spread * rng.random(n)
    volume = rng.lognormal(10, 0.5, n)
    idx = pd.date_range(start, periods=n, freq=freq, tz="UTC")
    return pd.DataFrame({"open": open_, "high": high, "low": low, "close": close, "volume": volume}, index=idx)


def bars(rows, start="2026-01-01 00:00", freq="min") -> pd.DataFrame:
    """rows = [(open, high, low, close), ...] → velas de 1 minuto."""
    idx = pd.date_range(start, periods=len(rows), freq=freq, tz="UTC")
    data = [{"open": o, "high": h, "low": l, "close": c, "volume": 1.0} for o, h, l, c in rows]
    return pd.DataFrame(data, index=idx)


# ----------------------------------------------------------------------
# Exchange simulado a nivel de BybitAPIManager (para brokers y bot)
# ----------------------------------------------------------------------
class FakeExchangeAPI:
    """Imita la interfaz de BybitAPIManager con un mini exchange en memoria (modo one-way)."""

    def __init__(self, prices: Optional[Dict[str, float]] = None):
        self.prices = dict(prices or {"BTC/USDT:USDT": 60000.0})
        self.positions: Dict[str, Dict[str, Any]] = {}
        self.orders: Dict[str, Dict[str, Any]] = {}
        self.closed_pnl: Dict[str, List[dict]] = {}
        self.calls: List[tuple] = []
        self.minute_bars: Dict[str, pd.DataFrame] = {}
        self.entry_bars: Dict[str, pd.DataFrame] = {}
        self.funding_rate = 0.0001
        self.next_funding_ms = int(time.time() * 1000) + 3_600_000
        self.fail_positions = False
        self.drop_sl_on_entry = False
        self.reject_entry: Optional[Exception] = None
        self.markets_by_id = {"BTCUSDT": {"symbol": "BTC/USDT:USDT", "linear": True, "swap": True, "active": True}}
        self.last_error = ""
        self._n = 0

    # --- utilidades del simulador ---------------------------------
    def _oid(self) -> str:
        self._n += 1
        return f"ord{self._n}"

    def move(self, symbol: str, price: float) -> None:
        """Mueve el precio y ejecuta lo que toque (SL y TP límite), como haría Bybit."""
        self.prices[symbol] = price
        pos = self.positions.get(symbol)
        if not pos:
            return
        long = pos["side"] == LONG
        for oid, order in list(self.orders.items()):
            if order["symbol"] != symbol or not order.get("reduce_only"):
                continue
            hit = price >= order["price"] if long else price <= order["price"]
            if hit:
                qty = min(order["qty"], pos["contracts"])
                self._close_part(symbol, qty, order["price"])
                del self.orders[oid]
                pos = self.positions.get(symbol)
                if not pos:
                    return
        sl = pos.get("stop_loss")
        if sl and ((long and price <= sl) or (not long and price >= sl)):
            self._close_part(symbol, pos["contracts"], sl)

    def _close_part(self, symbol: str, qty: float, price: float) -> None:
        pos = self.positions[symbol]
        sign = 1 if pos["side"] == LONG else -1
        pnl = (price - pos["entry_price"]) * qty * sign
        fee = price * qty * 0.00055
        self.closed_pnl.setdefault(symbol, []).append({
            "symbol": symbol.split("/")[0] + "USDT", "closedPnl": str(pnl - fee), "closedSize": str(qty),
            "avgExitPrice": str(price), "avgEntryPrice": str(pos["entry_price"]), "openFee": "0",
            "closeFee": str(fee), "updatedTime": str(int(time.time() * 1000)),
        })
        pos["contracts"] = round(pos["contracts"] - qty, 10)
        if pos["contracts"] <= 1e-12:
            del self.positions[symbol]
            for oid in [o for o, v in self.orders.items() if v["symbol"] == symbol]:
                del self.orders[oid]

    # --- interfaz de BybitAPIManager ------------------------------------
    def limits(self, symbol: str) -> MarketLimits:
        return MarketLimits(qty_step=0.001, min_qty=0.001, min_notional=5.0, tick_size=0.1)

    def amount_to_precision(self, symbol: str, amount: float) -> float:
        return float(int(amount * 1000 + 1e-9) / 1000)

    def price_to_precision(self, symbol: str, price: float) -> str:
        return f"{round(price, 1)}"

    def market(self, symbol: str) -> dict:
        return {"symbol": symbol, "id": symbol.split("/")[0] + "USDT", "info": {}}

    def market_id(self, symbol: str) -> str:
        return symbol.split("/")[0] + "USDT"

    def max_leverage(self, symbol: str) -> int:
        return 100

    def is_st(self, symbol: str) -> bool:
        return False

    def listing_time_ms(self, symbol: str) -> Optional[int]:
        return None

    async def load_markets(self, reload: bool = False):
        return {}

    async def detect_account(self) -> str:
        return "UNIFICADA"

    async def ensure_one_way_mode(self) -> None:
        return None

    async def get_equity(self) -> Dict[str, float]:
        upnl = 0.0
        for sym, pos in self.positions.items():
            sign = 1 if pos["side"] == LONG else -1
            upnl += (self.prices[sym] - pos["entry_price"]) * pos["contracts"] * sign
        return {"equity": 10_000.0 + upnl, "available": 9_000.0, "wallet": 10_000.0, "upnl": upnl}

    async def fetch_open_positions(self) -> List[Dict[str, Any]]:
        self.calls.append(("fetch_open_positions",))
        if self.fail_positions:
            import ccxt
            raise ccxt.NetworkError("sin conexión simulada")
        return [{"symbol": s, "side": p["side"], "contracts": p["contracts"], "entry_price": p["entry_price"],
                 "mark_price": self.prices[s], "upnl": 0.0, "stop_loss": p.get("stop_loss"), "take_profit": None,
                 "leverage": 20, "liq_price": None, "position_idx": 0, "created_ms": 0}
                for s, p in self.positions.items()]

    async def set_leverage(self, symbol: str, leverage: int) -> None:
        self.calls.append(("set_leverage", symbol, leverage))

    async def create_entry_order(self, symbol, side, qty, stop_loss, client_id):
        self.calls.append(("create_entry_order", symbol, side, qty, stop_loss, client_id))
        if self.reject_entry:
            raise self.reject_entry
        price = self.prices[symbol]
        self.positions[symbol] = {"side": side, "contracts": qty, "entry_price": price,
                                  "stop_loss": None if self.drop_sl_on_entry else stop_loss}
        return {"id": self._oid()}

    async def create_reduce_only_limit(self, symbol, position_side, qty, price, client_id):
        self.calls.append(("create_reduce_only_limit", symbol, position_side, qty, price))
        oid = self._oid()
        self.orders[oid] = {"symbol": symbol, "qty": qty, "price": price, "reduce_only": True}
        return {"id": oid}

    async def close_market(self, symbol, position_side, qty):
        self.calls.append(("close_market", symbol, position_side, qty))
        if symbol in self.positions:
            self._close_part(symbol, min(qty, self.positions[symbol]["contracts"]), self.prices[symbol])
        return {"id": self._oid()}

    async def set_trading_stop(self, symbol, stop_loss=None, take_profit=None, position_idx=0):
        self.calls.append(("set_trading_stop", symbol, stop_loss))
        if symbol in self.positions and stop_loss is not None:
            self.positions[symbol]["stop_loss"] = float(stop_loss)

    async def fetch_open_orders(self, symbol):
        return [{"id": oid, **o} for oid, o in self.orders.items() if o["symbol"] == symbol]

    async def cancel_order(self, order_id, symbol):
        self.calls.append(("cancel_order", order_id))
        self.orders.pop(order_id, None)

    async def cancel_all_orders(self, symbol):
        for oid in [o for o, v in self.orders.items() if v["symbol"] == symbol]:
            del self.orders[oid]

    async def fetch_closed_pnl(self, symbol, start_ms, end_ms=None):
        return list(self.closed_pnl.get(symbol, []))

    async def fetch_ticker(self, symbol):
        return {"last": self.prices[symbol], "mark": self.prices[symbol], "funding_rate": self.funding_rate,
                "next_funding_ms": self.next_funding_ms}

    async def fetch_ohlcv(self, symbol, timeframe, limit=None):
        df = self.entry_bars.get(symbol)
        if df is None:
            df = random_walk(300, seed=1, price=self.prices.get(symbol, 100.0), vol=0.002)
        return df.tail(limit or len(df))

    async def fetch_ohlcv_range(self, symbol, timeframe, since_ms, until_ms=None, closed_only=True):
        df = self.minute_bars.get(symbol, pd.DataFrame())
        if df.empty:
            return df
        return df[df.index >= pd.Timestamp(int(since_ms), unit="ms", tz="UTC")]

    async def fetch_linear_tickers(self):
        return []

    def status(self):
        return {"mode": "TEST", "account_type": "UNIFICADA", "consecutive_failures": 0, "last_error": "", "markets": 1}

    async def close(self):
        return None


@pytest.fixture
def fake_api():
    return FakeExchangeAPI()
