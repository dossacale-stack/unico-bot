"""Mercado sintético para probar el backtest sin red (no sirve para medir rentabilidad)."""
import numpy as np, pandas as pd, time
from config import tf_ms

def regime_series(seed, start_ms, end_ms, tf="1h"):
    step = tf_ms(tf)
    n = int((end_ms - start_ms) // step)
    r = np.random.default_rng(seed)
    rets = []
    while len(rets) < n:
        seg = int(r.integers(150, 500)); drift = float(r.choice([-0.0025, 0.0025, 0.0]))
        rets.extend(r.normal(drift, 0.01, seg))
    rets = np.array(rets[:n]) * (60 / (step / 60000)) ** -0.5 if tf != "1h" else np.array(rets[:n])
    close = 50 * np.exp(np.cumsum(rets))
    open_ = np.concatenate([[close[0]], close[:-1]])
    wick = np.abs(r.normal(0, 0.007, n)) * close
    high = np.maximum(open_, close) + wick * r.random(n) * 1.6
    low = np.minimum(open_, close) - wick * r.random(n) * 1.6
    vol = r.lognormal(10, 0.6, n)
    idx = pd.date_range(pd.Timestamp(start_ms, unit="ms", tz="UTC"), periods=n, freq=f"{step//60000}min")
    return pd.DataFrame({"open": open_, "high": high, "low": low, "close": close, "volume": vol}, index=idx)

class FakeData:
    def __init__(self, n_symbols=40):
        self.symbols = [f"C{i:02d}/USDT:USDT" for i in range(n_symbols)]
        now = int(time.time() * 1000)
        self.base_start = ((now - 400 * 86_400_000) // 86_400_000) * 86_400_000
        self.frames = {}
    def market_ids(self):
        return {s: s.split("/")[0] + "USDT" for s in self.symbols}
    def market_info(self, s):
        return {"symbol": s, "id": s.split("/")[0] + "USDT", "info": {"lotSizeFilter": {"qtyStep": "0.001", "minOrderQty": "0.001", "minNotionalValue": "5"}, "priceFilter": {"tickSize": "0.0001"}, "leverageFilter": {"maxLeverage": "50"}}}
    def ohlcv(self, s, tf, since, until):
        key = (s, tf)
        if key not in self.frames:
            self.frames[key] = regime_series(self.symbols.index(s) * 7 + (0 if tf == "1h" else 1000), self.base_start, int(time.time()*1000), tf)
        df = self.frames[key]
        return df[(df.index >= pd.Timestamp(since, unit="ms", tz="UTC")) & (df.index <= pd.Timestamp(until, unit="ms", tz="UTC"))]
    def ohlcv_many(self, symbols, tf, since, until, cb):
        out = {}
        for i, s in enumerate(symbols):
            out[s] = self.ohlcv(s, tf, since, until); cb(i + 1, len(symbols))
        return out
    def funding(self, s, start, end):
        ts = list(range((start // 28_800_000 + 1) * 28_800_000, end, 28_800_000))
        r = np.random.default_rng(len(s))
        return [(t, float(r.normal(0.0001, 0.0002))) for t in ts]
    def daily(self, s):
        df = self.ohlcv(s, "1h", self.base_start, int(time.time()*1000))
        return df.resample("1D").agg({"open": "first", "high": "max", "low": "min", "close": "last", "volume": "sum"}).dropna()
